module.exports = {
  spotify : {
    clientid : '8cf0e8942a7e4dcf8f7d536a5f9802a4',
    clientsecret : 'd01e3d26a68a48949c8b02b046a58dba'
  },
  youtube : {
    apikey : 'AIzaSyBIxGhkKY0lsYLo5dF67kNeX9bYsgE_-yo'
  },
  directory : '/Music'
};
